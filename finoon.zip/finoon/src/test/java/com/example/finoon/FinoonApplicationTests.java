package com.example.finoon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinoonApplicationTests {

	@Test
	void contextLoads() {
	}

}
